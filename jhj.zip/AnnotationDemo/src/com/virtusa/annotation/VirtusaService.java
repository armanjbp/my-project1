package com.virtusa.annotation;

import java.lang.annotation.Target;

import com.virtusa.controller.EmployeeController;

public interface VirtusaService {
	
}
