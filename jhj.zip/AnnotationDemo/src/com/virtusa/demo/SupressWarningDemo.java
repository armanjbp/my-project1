package com.virtusa.demo;

import java.util.ArrayList;
import java.util.List;

public class SupressWarningDemo {

	@SuppressWarnings(value = { "unused", "unchecked", "rawtypes" })
	public static void main(String[] args) {

		int i = 10;
		// TODO Auto-generated method stub
		List list = new ArrayList();
		list.add(10);

	}

}
