package com.virtusa.demo;

public class DeprecatedDemo {

	/***
	 * @author admin
	 * @see x_new x() method has a bug, may return null in some scenarios
	 * 
	 */
	@Deprecated
	public void x() {
		System.out.println("--x--");
	}

	public void x_new() {
		System.out.println("--x new--");
	}

	public static void main(String args[]) {
		DeprecatedDemo deprecated=new DeprecatedDemo();
		deprecated.x();
	}
}
