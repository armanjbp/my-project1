package com.virtusa.processing;

import com.virtusa.annotation.VirtusaController;
import com.virtusa.annotation.VirtusaService;
import com.virtusa.annotation.VirtusaTable;
import com.virtusa.controller.EmployeeController;

public class AnnotationProcessingDemo
{
	public static void main(String args[])
	{
	Class classDataVirtusaController=	EmployeeController.class;
VirtusaController virtusaController=(VirtusaController)	classDataVirtusaController.getAnnotation(VirtusaController.class);
	
if(virtusaController!=null)
	System.out.print("its controller");
else
{
	System.out.println("its not");
}
Class employeeService= VirtusaService.class;

if(VirtusaTable!=null)
{
	System.out.println("yes"));
}
else
{
	System.out.println("not");
}



	}
	
	
}
