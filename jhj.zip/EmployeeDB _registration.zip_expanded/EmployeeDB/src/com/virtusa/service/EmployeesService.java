package com.virtusa.service;

import java.util.List;

import com.virtusa.entities.Employees;
import com.virtusa.model.EmployeesModel;
import com.virtusa.model.RegisterEmployeesModel;

public interface EmployeesService {
	
	public List<EmployeesModel> retrieveEmployees();
	public EmployeesModel retrieveDepartmentName(int employeeId);
	public String registerEmployee(RegisterEmployeesModel model);

}
