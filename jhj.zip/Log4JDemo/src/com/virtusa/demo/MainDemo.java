package com.virtusa.demo;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

public class MainDemo {
	public List<String> getNames() {
		List<String> listStrings = new ArrayList<String>();
		listStrings.add("sabbir");
		listStrings.add("amit");
		listStrings.add("aman");
		listStrings.add("abdul");
		return listStrings;
	}

	static Logger log = Logger.getLogger(MainDemo.class.getName());

	public static void main(String[] args) {
		MainDemo mainDemo = new MainDemo();

		log.debug("getName() returned list ==>" + mainDemo.getNames());
		BasicConfigurator.configure();
		log.info("logger configured successfully");
		log.info("main method started");
		try {
			int c = 1 / 0;
		} catch (ArithmeticException e) {

			
			log.error("exception occured" + e.getMessage());
		}

	}

}
