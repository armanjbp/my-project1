package com.virtusa.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class CallableDemo {

	public static void main(String[] args) {
		Callable<Integer> task1 = () -> {
			return (int) (Math.random() * 100);
		};
		Callable<Integer> task2 = () -> {
			return (int) (Math.random() * 100);
		};
		Callable<Integer> task3 = () -> {
			return (int) (Math.random() * 100);
		};

		List<Callable> tasks = new ArrayList<>();
		tasks.add(task1);
		tasks.add(task2);
		tasks.add(task3);
		ExecutorService executorService = Executors.newFixedThreadPool(2);
		List<Future<Integer>> futures = new ArrayList<>();

		for (Callable task : tasks) {
			Future<Integer> future = executorService.submit(task);
			futures.add(future);
		}
		for (Future<Integer> future : futures) {
			try {
				System.out.println("Random number :" + future.get());
			} catch (InterruptedException | ExecutionException e) {
				
				e.printStackTrace();
			}
		}
		try {
			executorService.awaitTermination(5, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}
		executorService.shutdown();
	}

}
