package com.virtusa.demo;

public class Consumer implements Runnable {

	public Queue queue;
	public Consumer(Queue queue) {
	this.queue=queue;
	}
	
	
	
	@Override
	public void run() {
		while(true)
		{
			queue.get();
		}
		
	}

}
