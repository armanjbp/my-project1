package com.virtusa.demo;

public class MultithreadedApplication {

	class SumTask extends Thread {
		@Override
		public void run() {
			System.out.print("final sum :" + sum());

		}

		public int sum() {

			int sum = 0;
			for (int i = 1; i <= 20; i++) {
				sum += i;
				System.out.println("sum done far : " + sum);
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			return sum;
		}

	}

	class ProductTask implements Runnable {

		@Override
		public void run() {
			System.out.println("product is " + product());

		}

		public double product() {
			double product = 1;
			for (int i = 1; i <= 20; i++) {
				product *= i;
				System.out.println("product done so far : " + product);
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return product;
		}

	}

	public static void main(String args[]) {
		System.out.print("--application started--");
		MultithreadedApplication app = new MultithreadedApplication();

		Thread sumWorker = new Thread(app.new SumTask(), "sumWorker");
		sumWorker.start();
		Thread productWorker = new Thread(app.new ProductTask(), "product worker");
		productWorker.start();

		Runnable r = new Runnable() {

			@Override
			public void run() {
			}

			public double division() {
				double division = 0;
				for (int i = 1; i <= 10; i++) {
					division /= i;
					System.out.println("division done so far :" + division);
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {

						e.printStackTrace();
					}
				}
				return division;
			}

		};

		Thread divisionWorker = new Thread(r, "division wroker");
		divisionWorker.start();

		Runnable lambda = () -> {
			double mod = 0;
			for (int i = 0; i <= 20; i++) {
				mod %= i;
				System.out.println("mod done so far :" + mod);
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println("final mod :" + mod);
		};

		Thread modWorker = new Thread(lambda, "mod worker");
		modWorker.start();
		while (true) {

		}

	}

}
