package com.virtusa.demo;

public class SingleThreadedApplication {
	public int sum() {
		int sum = 0;
		for (int i = 1; i <= 20; i++) {
			sum += i;
			System.out.println("sum done so far: " + sum);

		}
		return sum;
	}

	public double product() {
		int product = 1;
		for (int i = 1; i <= 20; i++) {
			product *= i;
			System.out.println("product done so far :" + product);
		}
		return product();
	}

	public static void main(String args[]) {
		Thread current = Thread.currentThread();

		System.out.print("Current thread :" + current);

		SingleThreadedApplication app = new SingleThreadedApplication();
		System.out.print("sum is :" + app.sum());
		System.out.print("product is :" + app.product());

//		while (true) {
//
//		}
	}

}
