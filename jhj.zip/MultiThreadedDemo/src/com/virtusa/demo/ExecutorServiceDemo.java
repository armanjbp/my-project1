package com.virtusa.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ExecutorServiceDemo {

	public static void main(String[] args) {
		Runnable task1 = () -> {

			System.out.println("--task1--");

		};

		Runnable task2 = () -> {

			System.out.println("--task2--");

		};
		Runnable task3 = () -> {

			System.out.println("--task3--");

		};
		List<Runnable> tasks = new ArrayList<>();
		tasks.add(task1);
		tasks.add(task2);
		tasks.add(task3);

		ExecutorService executorService = Executors.newFixedThreadPool(2);
		for (Runnable task : tasks) {
			executorService.execute(task);
		}
		try {
			executorService.awaitTermination(5, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		executorService.shutdown();
	}

}
