package com.virtusa.demo;

public class ProducerConsumerDemo {

	public static void main(String args[]) {
		Queue queue = new Queue();
		Producer producer = new Producer(queue);
		Consumer consumer = new Consumer(queue);

		Producer producer2 = new Producer(queue);
		Consumer consumer2 = new Consumer(queue);

		Thread producerWorker = new Thread(producer, "producer");
		Thread consumerWorker = new Thread(consumer, "consumer");

		Thread producerWorker2 = new Thread(producer2, "producer");
		Thread consumerWorker2 = new Thread(consumer2, "consumer");

		producerWorker.start();
		consumerWorker.start();
		producerWorker2.start();
		consumerWorker2.start();
	}
}
