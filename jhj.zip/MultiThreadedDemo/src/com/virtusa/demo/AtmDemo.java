package com.virtusa.demo;

public class AtmDemo {

	public static void main(String args[])
	{
		ATM atm=new  ATM();
		atm.setAtmLocation("hyd");
		atm.setBankName("hdfc");
		
		Customer customer1=new Customer(atm,"sabbir ");
		Customer customer2=new Customer(atm,"aman ");
		Customer customer3=new Customer(atm,"chaman ");
		Customer customer4=new Customer(atm,"abdul ");
		Customer customer5=new Customer(atm,"bhau ");
		Customer customer6=new Customer(atm,"parmit ");
		
		Thread worker1=new Thread(customer1);
		Thread worker2=new Thread(customer2);
		Thread worker3=new Thread(customer3);
		Thread worker4=new Thread(customer4);
		Thread worker5=new Thread(customer5);
		Thread worker6=new Thread(customer6);
		worker1.start();
		worker2.start();
		worker3.start();
		worker4.start();
		worker5.start();
		worker6.start();
		
		
		
	}
	
}
