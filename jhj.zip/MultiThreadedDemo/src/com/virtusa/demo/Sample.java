package com.virtusa.demo;

import java.util.Random;

public class Sample extends Thread
{
	public static void main(String args[]) {

		
		
		new Random().ints(10, 1, 20).forEach(System.out::print);
		
	}
}
