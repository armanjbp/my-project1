package com.virtusa.login;

public class ApplicantLogin {
	public void applicantLoginWindow() {
		System.out.println("=======Applicant Login======");
	}
}
