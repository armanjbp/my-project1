package com.virtusa.login;

public class HrLogin {
	public void hrLoginWindow() {
		System.out.println("=======Hr login======");
	}
}
