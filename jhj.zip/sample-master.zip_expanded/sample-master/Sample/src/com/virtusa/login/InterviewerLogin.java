package com.virtusa.login;

public class InterviewerLogin {
	public void interviewerLoginWindow() {
		System.out.println("=======Interviewer login======");
	}
}
