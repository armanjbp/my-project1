package com.virtusa.login;

public class ManagerLogin {
	public void managerLoginWindow() {
		System.out.println("=======Manager login======");
	}
}
