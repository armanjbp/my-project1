package com.virtusa.login;

public class AdminLogin {
	public void adminLoginWindow() {
		System.out.println("=======Admin login======");
	}
}
