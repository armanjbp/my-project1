package com.virtusa.service;

import com.virtusa.model.UserModel;

public interface UserService {
    
	public String userAuthenticationService(UserModel userModel);
}
