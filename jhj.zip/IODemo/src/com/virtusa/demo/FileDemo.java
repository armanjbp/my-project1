package com.virtusa.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class FileDemo {

	public static void main(String args[]) {
		File file = new File("C:\\IO");
		System.out.println("dir exist :" + file.exists());

		File file1 = new File("c:\\IO\\File1.txt");

		System.out.println("file1 exist :" + file1.exists());
		System.out.println("file1 length :" + file1.length());
		System.out.println("file1 excute :" + file1.canExecute());
		
		
		File file2=new File("c:\\IO\\File2.txt");
		
		
		try (InputStream is = new FileInputStream(file1);
				OutputStream os=new FileOutputStream(file2);
				
				) 
		{
			int k = 0;
			while ((k = is.read()) != -1) {
			//	System.out.print((char) k);
				os.write((char)k);

			}

		} catch (IOException e) {

		}

	}
}
