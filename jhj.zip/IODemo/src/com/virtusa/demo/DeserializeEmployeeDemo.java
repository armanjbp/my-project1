package com.virtusa.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;

public class DeserializeEmployeeDemo 
{
	public static void main(String args[]) throws IOException, ClassNotFoundException
	{
	File file=new File("C:\\IO\\employee.ser");
	InputStream is=new FileInputStream(file);
ObjectInputStream ois=	new ObjectInputStream(is);
Employee e=(Employee)ois.readObject();
System.out.print(e);
ois.close();
}}
