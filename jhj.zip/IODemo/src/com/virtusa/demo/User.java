package com.virtusa.demo;

import java.io.File;

import java.io.FileReader;

public class User 
{
	
    private long id;
    private String name;
    private String mobileNumber;
    private String username;
    private String password;
    
    
    
	public User() {
		super();
	}
	
	public User(long id, String name, String mobileNumber, String username, String password) {
		super();
		this.id = id;
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.username = username;
		this.password = password;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", mobileNumber=" + mobileNumber + ", username=" + username
				+ ", password=" + password + "]";
	}
    
    
    
   

	}
