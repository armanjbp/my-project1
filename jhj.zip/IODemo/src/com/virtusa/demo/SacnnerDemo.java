package com.virtusa.demo;

import java.util.Scanner;

public class SacnnerDemo {

	public static void main(String[] args) 
	{
		
		Scanner scanner= new Scanner(System.in);
		System.out.print("please enter salary");
		
		if(scanner.hasNextDouble())
		{
			double salary=scanner.nextDouble();
			double tax=salary*0.01;
			System.out.print("Tax :"+tax );
		}
		else
		{
			scanner.close();
			throw new RuntimeException("inavlid salary");
		}
		scanner.close();
		
	}

}
