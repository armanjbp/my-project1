package com.virtusa.demo;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessFileDemo {

	public static void main(String args[]) throws IOException {
		File file5 = new File("C:\\IO\\file5.txt");
		RandomAccessFile random = new RandomAccessFile(file5, "rw");
		String data="java is world";
		random.seek(5);
		random.writeBytes(data);
		random.close();
	}
}
