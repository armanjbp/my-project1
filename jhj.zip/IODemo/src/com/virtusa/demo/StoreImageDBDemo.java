package com.virtusa.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.util.Properties;

public class StoreImageDBDemo {

	public static void main(String[] args) {
		File file = new File("C:\\IO\\DB.properties");
		Properties properties = new Properties();

		try (InputStream is = new FileInputStream(file)) {
			properties.load(is);
		} catch (IOException e)
		{
			e.printStackTrace();

		}

		try {
			Class.forName(properties.getProperty("driver"));
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
		try (InputStream is = new FileInputStream(new File("C:\\IO\\virtusa_logo.png"));
				Connection conn = DriverManager.getConnection(properties.getProperty("url"),
						properties.getProperty("username"), properties.getProperty("password"));

		) {

			PreparedStatement preparedStatement = conn.prepareCall("insert into IMAGETABLE values(?,?)");
			preparedStatement.setInt(1, 1);
			preparedStatement.setBlob(2, is);
			int rows = preparedStatement.executeUpdate();
			if (rows > 0)
				System.out.print("inserted");
			else
				System.out.print("not inserted");

		} catch (Exception e) 
		{
			e.printStackTrace();

		}
	}

}
