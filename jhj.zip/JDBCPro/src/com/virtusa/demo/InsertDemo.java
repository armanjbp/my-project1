package com.virtusa.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertDemo {
	public static void main(String args[]) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
		try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "hr", "hr");

		) {
			PreparedStatement st = conn.prepareStatement("insert into student_info(studentseq.nextval,?)");
			st.setString(1, "rohit");
			int rows = st.executeUpdate();
			if (rows > 0) {
				System.out.print(" inserted");

			} else {
				System.out.print("not inserted");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
