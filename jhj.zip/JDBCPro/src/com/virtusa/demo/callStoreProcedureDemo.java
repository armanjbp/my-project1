package com.virtusa.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;

public class callStoreProcedureDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	Class.forName("oracle.jdbc.driver.OracleDriver");
} catch (ClassNotFoundException e) {
	
	e.printStackTrace();
}
try(Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "hr", "hr"))
{
CallableStatement st=	conn.prepareCall("{call RetrieveJobTitle(?,?)}");
st.registerOutParameter(2, Types.VARCHAR);
st.setInt(1, 106);
st.execute();
String jobTitle=st.getString(2);
System.out.print("job title : "+jobTitle);
}
catch(SQLException e)
{
	e.printStackTrace();
	
}
	}

}
