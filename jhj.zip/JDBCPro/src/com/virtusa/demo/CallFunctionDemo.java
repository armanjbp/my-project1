package com.virtusa.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CallFunctionDemo {

	public static void main(String[] args) {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
		try (Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "hr", "hr")) {
			PreparedStatement st = con
					.prepareStatement("select salary, tax_calc(salary)from EMPLOYEES where EMPLOYEE_ID=?");
			st.setInt(1, 105);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				System.out.print("Tax :" + rs.getInt(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();

		}
	}

}
