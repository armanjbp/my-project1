package Controller;

import pack1.view;

public class controller
{
	public int log(String input)
	{
	view v=new view();
	String n=v.type(input);
	int num=Integer.parseInt(n);
	return num;
	}
}
