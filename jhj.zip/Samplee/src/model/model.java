package model;

import java.util.ArrayList;

public class model 
{
	public int store(int num)
	{
		
		return num;
	}

}
