package pack1;

import java.util.Scanner;

import model.model;

public class view 
{
	String input;
	public String type(String name)
	{
		
		return input;
	}
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.print("please enter string");;
		String inp=s.next();
		view v=new view();
		v.type(inp);
	
		
	}

}
