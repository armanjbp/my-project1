package com.virtusa.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;

public class JDBC {

	public static void main(String[] args) 
	{


		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
	
	try(Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "hr", "hr");)
	{
PreparedStatement pt=	conn.prepareStatement("select FIRST_NAME from EMPLOYEES where EMPLOYEE_ID=?;");
	pt.setString(1, "105");
	ResultSet rs=pt.executeQuery();
	while(rs.next())
	{
		System.out.print(rs.getString(1));
	}

	
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	}
	

}
